const freqs = document.getElementById('freqs');
const audio = document.getElementById('radio21');

// List of frequency numbers, including 21
const frequencies = [0, 5, 10, 15, 20, 21, 25, 30, 35, 40];

frequencies.forEach((freqValue) => {
  const freq = document.createElement('div');
  freq.className = 'frequency';
  freq.innerText = freqValue;
  freq.addEventListener('click', () => {
    // Remove active state from all frequencies
    document.querySelectorAll('.frequency').forEach(el => el.classList.remove('active'));
    freq.classList.add('active');

    // Play audio only if frequency is 21
    if (freqValue === 21) {
      audio.play();
    } else {
      audio.pause();
      audio.currentTime = 0;
    }
  });
  freqs.appendChild(freq);
});
